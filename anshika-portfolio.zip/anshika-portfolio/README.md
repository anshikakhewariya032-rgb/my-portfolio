# Anshika Khewariya Portfolio

A React portfolio site built with Vite.

## Run it

You need Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the address it prints (usually http://localhost:5173).

## Edit your content

All text lives in `src/data.js`: your intro, projects, experience, skills, certifications, education and contact details. Change it there and the site updates.

To make your LinkedIn a link, set `linkedinUrl` in `src/data.js`.

## Publish it

```bash
npm run build
```

This creates a `dist/` folder. Upload it to any static host such as Netlify, Vercel or GitHub Pages.

## Structure

- `src/data.js`: all content
- `src/App.jsx`: page sections
- `src/styles.css`: styling, with light and dark themes
