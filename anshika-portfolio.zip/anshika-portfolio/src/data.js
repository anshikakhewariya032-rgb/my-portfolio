// All the text on the site lives here. Edit this file to update your portfolio.

export const profile = {
  name: "Anshika Khewariya",
  initials: "A.K.",
  status: "Open to internships",
  intro:
    "B.Tech student in Computer Science & Design at MITS Gwalior. I write, design and build, from content and posters to C and web projects, and I'm looking for an internship where I can do all three.",
  email: "anshikakhewariya032@gmail.com",
  linkedin: "Anshika Khewariya", // add a full profile URL in linkedinUrl to make it a link
  linkedinUrl: "",
  location: "Gwalior, Madhya Pradesh",
};

export const featuredProject = {
  meta: "NAKSHATRA AEROSPACE HACKATHON 2026 · TEAM ASTRONOVA",
  title: "ORBITGUARD",
  tagline: "Dynamic GNN-Based Space Debris Risk & Mitigation System",
  description:
    "Earth orbit is getting crowded, and satellite operators need more than a list of tracked debris. ORBITGUARD turns debris tracking into collision-avoidance decision support: it explains why a risk changes, lets operators test a response, and points to the safest maneuver they can afford.",
  parts: [
    {
      title: "Dynamic risk graph",
      text: "A space-weather-aware debris graph that shows how collision risk shifts over time.",
    },
    {
      title: "What-if simulator",
      text: "An interactive tool to try a maneuver and see the outcome before committing.",
    },
    {
      title: "Fuel-aware analysis",
      text: "Weighs safety against fuel cost to find the safest affordable option.",
    },
  ],
};

export const projects = [
  {
    meta: "C LANGUAGE",
    title: "Personal Expense Tracker",
    text: "A program that records and categorizes personal spending and totals it up.",
    points: [
      "File handling to store and manage expense data",
      "Logic for expense categories and total calculation",
    ],
  },
  {
    meta: "HTML & CSS",
    title: "Department Information System",
    text: "A responsive web system for managing department information.",
    points: [
      "Organizes faculty, courses, syllabus and timetable",
      "Modern CSS techniques for layout and visual design",
    ],
  },
  {
    meta: "IN PROGRESS · FRONTEND",
    title: "College Use Project",
    text: "A project I'm building for use at my college, where I'm putting my frontend learning into practice.",
    points: [],
  },
];

export const experience = [
  {
    title: "Fundraising Intern, NayePankh Foundation",
    when: "",
    points: [
      "Took part in fundraising campaigns and donor engagement activities",
      "Supported NGO initiatives through outreach, awareness and promotion",
      "Built communication and persuasive interaction skills",
    ],
  },
  {
    title: "ACM Student Chapter, MITS",
    when: "Member",
    text: "Part of my college's ACM student chapter, working alongside other students on technology activities and learning.",
  },
  {
    title: "IEEE Hackathon",
    when: "National level · 2026",
    text: "Recently took part in a national-level hackathon organized under IEEE, alongside the Nakshatra Aerospace Hackathon.",
  },
  {
    title: "Smart India Hackathon",
    when: "Internal round · cleared",
    text: "Cleared the college's internal selection round for Smart India Hackathon.",
  },
];

export const skills = [
  {
    group: "Writing & communication",
    items: ["Content writing", "Creative writing", "Communication", "Research"],
  },
  {
    group: "Technical",
    items: ["C", "Python", "HTML", "CSS", "Frontend development (learning)"],
  },
  { group: "Tools", items: ["Canva", "MS Word", "Google Docs"] },
];

export const certifications = [
  { title: "Introduction to Data Science", by: "Infosys Springboard" },
  { title: "Introduction to Artificial Intelligence", by: "Infosys Springboard" },
  { title: "Fundraising Internship Certificate", by: "NayePankh Foundation" },
  { title: "IEEE Hackathon, national level", by: "IEEE" },
  { title: "Designathon, poster making competition", by: "MITS" },
];

export const education = [
  {
    title: "B.Tech, Computer Science & Design",
    place: "Madhav Institute of Technology & Science, Gwalior",
    when: "2025 – 2029",
  },
  {
    title: "Class 12 · 84.2%",
    place: "Scholars Public Higher Secondary School, Niwari",
    when: "2024",
  },
  {
    title: "Class 10 · 92.2%",
    place: "Scholars Public Higher Secondary School, Niwari",
    when: "2022",
  },
];

export const interests = [
  "Writing and content creation",
  "Poster and graphic design",
  "Learning new technologies",
  "Social initiatives",
];
