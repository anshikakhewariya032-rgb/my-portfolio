import { useEffect, useRef, useState } from "react";
import {
  profile,
  featuredProject,
  projects,
  experience,
  skills,
  certifications,
  education,
  interests,
} from "./data.js";

function Section({ id, label, children, className = "" }) {
  return (
    <section id={id} className={className}>
      <p className="label">{label}</p>
      {children}
    </section>
  );
}

function ThemeToggle() {
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem("theme") || "system";
    } catch {
      return "system";
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "system") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", theme);
    try {
      localStorage.setItem("theme", theme);
    } catch {
      /* storage unavailable */
    }
  }, [theme]);

  const next = { system: "light", light: "dark", dark: "system" };
  return (
    <button
      type="button"
      className="theme-btn"
      onClick={() => setTheme(next[theme])}
      aria-label={`Theme: ${theme}. Click to change.`}
    >
      {theme}
    </button>
  );
}

function Nav() {
  return (
    <nav>
      <span className="mark">{profile.initials}</span>
      <div className="links">
        <a href="#projects">Projects</a>
        <a href="#experience">Experience</a>
        <a href="#skills">Skills</a>
        <a href="#contact">Contact</a>
        <ThemeToggle />
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <header className="hero">
      <svg className="orbit" viewBox="0 0 260 260" aria-hidden="true">
        <circle cx="130" cy="130" r="30" />
        <circle cx="130" cy="130" r="78" />
        <circle className="ring2" cx="130" cy="130" r="122" />
        <circle className="sat" cx="208" cy="130" r="5" />
        <circle className="sat" cx="62" cy="52" r="3.5" />
      </svg>
      <div className="status">
        <i /> {profile.status}
      </div>
      <h1>{profile.name}</h1>
      <p className="lede">{profile.intro}</p>
      <div className="cta">
        <a className="btn primary" href="#projects">See my work</a>
        <a className="btn" href="#contact">Get in touch</a>
      </div>
    </header>
  );
}

function Projects() {
  const f = featuredProject;
  return (
    <Section id="projects" label="Projects">
      <article className="project">
        <div className="meta">{f.meta}</div>
        <h3>{f.title}</h3>
        <p className="tag">{f.tagline}</p>
        <p>{f.description}</p>
        <ul className="parts">
          {f.parts.map((p) => (
            <li key={p.title}>
              <b>{p.title}</b>
              {p.text}
            </li>
          ))}
        </ul>
      </article>

      <div className="pair">
        {projects.map((p) => (
          <article className="project plain" key={p.title}>
            <div className="meta">{p.meta}</div>
            <h3>{p.title}</h3>
            <p>{p.text}</p>
            {p.points.length > 0 && (
              <ul className="plainlist">
                {p.points.map((pt) => (
                  <li key={pt}>{pt}</li>
                ))}
              </ul>
            )}
          </article>
        ))}
      </div>
    </Section>
  );
}

function Experience() {
  return (
    <Section id="experience" label="Experience & involvement">
      {experience.map((e) => (
        <div className="entry" key={e.title}>
          <div className="job">
            <h3>{e.title}</h3>
            {e.when && <span>{e.when}</span>}
          </div>
          {e.text && <p>{e.text}</p>}
          {e.points && (
            <ul className="plainlist">
              {e.points.map((pt) => (
                <li key={pt}>{pt}</li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </Section>
  );
}

function Skills() {
  return (
    <Section id="skills" label="Skills">
      {skills.map((s) => (
        <div className="skillgroup" key={s.group}>
          <h3>{s.group}</h3>
          <ul className="chips">
            {s.items.map((i) => (
              <li key={i}>{i}</li>
            ))}
          </ul>
        </div>
      ))}
    </Section>
  );
}

function Certifications() {
  return (
    <Section id="certifications" label="Certifications">
      <ul className="certs">
        {certifications.map((c) => (
          <li key={c.title}>
            {c.title} <span>{c.by}</span>
          </li>
        ))}
      </ul>
    </Section>
  );
}

function Education() {
  return (
    <Section id="education" label="Education">
      {education.map((e) => (
        <div className="edu-row" key={e.title}>
          <div>
            <b>{e.title}</b>
            <small>{e.place}</small>
          </div>
          <div className="when">{e.when}</div>
        </div>
      ))}
    </Section>
  );
}

function Interests() {
  return (
    <Section id="interests" label="Interests">
      <ul className="chips">
        {interests.map((i) => (
          <li key={i}>{i}</li>
        ))}
      </ul>
    </Section>
  );
}

function Contact() {
  const [copied, setCopied] = useState(false);
  const mailRef = useRef(null);

  function selectText() {
    const range = document.createRange();
    range.selectNodeContents(mailRef.current);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(profile.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      selectText();
    }
  }

  return (
    <Section id="contact" label="Contact" className="contact">
      <h2>Looking for an internship? Let's talk.</h2>
      <dl>
        <dt>Email</dt>
        <dd ref={mailRef}>{profile.email}</dd>
        <dt>LinkedIn</dt>
        <dd>
          {profile.linkedinUrl ? (
            <a href={profile.linkedinUrl} target="_blank" rel="noreferrer">
              {profile.linkedin}
            </a>
          ) : (
            profile.linkedin
          )}
        </dd>
        <dt>Location</dt>
        <dd>{profile.location}</dd>
      </dl>
      <button className="btn" type="button" onClick={copy}>
        Copy email
      </button>
      {copied && <span className="copied">Copied</span>}
    </Section>
  );
}

export default function App() {
  return (
    <div className="wrap">
      <Nav />
      <Hero />
      <Projects />
      <Experience />
      <Skills />
      <Certifications />
      <Education />
      <Interests />
      <Contact />
      <footer>
        <span>{profile.name}</span>
        <span>MITS Gwalior · 2026</span>
      </footer>
    </div>
  );
}
